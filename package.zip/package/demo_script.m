
clc;clear;close all;
% DEMO SCRIPT FOR THE SUBMISSION ENTITLED 
% Enhancing microseismic signal using cross-correlation and singular value decomposition
% BY HUI LV
% 2019

d1=zeros(3101,240);
load data

d=d1(350:350+350,15:14+50);d=scalecyk(d,2);

[n1,n2]=size(d);
figure;wigbcyk(d);

d1=d(1:190,:);
d2=d(191:end,:);
[ shift1 ] = dip_steering( d1, d1(:,1));
[ shift2 ] = dip_steering( d2, d2(:,1));

d1_s=seisdither(d1,shift1);
d2_s=seisdither(d2,shift2);

d_s=[d1_s;d2_s];
figure;imagesc([d,d_s]);


D1=[d1;zeros(351-190,n2)];
figure;imagesc(D1);

D2=[zeros(190,n2);d2];
figure;imagesc(D2);


%%
[nz,nx]=size(D1(:,1:3:end));
x=1:nx;
z=1:nz;

randn('state',201819);
Dn1=D1+0.3*randn(size(D1));
[ Shift1 ] = dip_steering( D1, D1(:,1));
D1_s=seisdither(Dn1,Shift1);

%% SVD after dip steering
[u,e,v]=svd(D1_s);
r=1;
D1_svd=u(:,1:r)*e(1:r,1:r)*v(:,1:r)';
D1_dn=seisdither(D1_svd,-Shift1);

figure;wigbh(D1(:,1:3:end),x,z,1);ylim([0,18]);
ylabel('Channel NO','Fontsize',20);
xlabel('Time (ms)','Fontsize',20);
set(gca,'Linewidth',2,'Fontsize',20);

figure;wigbh(Dn1(:,1:3:end),x,z,1);ylim([0,18]);
ylabel('Channel NO','Fontsize',20);
xlabel('Time (ms)','Fontsize',20);
set(gca,'Linewidth',2,'Fontsize',20);

figure;plot(x,Shift1(1:3:end),'-or','linewidth',2);xlim([1,nx]);
ylabel('Shifts','Fontsize',20);
xlabel('Channel NO','Fontsize',20);
set(gca,'Linewidth',2,'Fontsize',20);

figure;wigbh(D1_s(:,1:3:end),x,z,1);ylim([0,18]);
ylabel('Channel NO','Fontsize',20);
xlabel('Time (ms)','Fontsize',20);
set(gca,'Linewidth',2,'Fontsize',20);

figure;wigbh(D1_dn(:,1:3:end),x,z,1);ylim([0,18]);
ylabel('Channel NO','Fontsize',20);
xlabel('Time (ms)','Fontsize',20);
set(gca,'Linewidth',2,'Fontsize',20);

